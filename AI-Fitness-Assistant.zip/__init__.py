"""Text extraction providers."""
