"""SQLite persistence."""
