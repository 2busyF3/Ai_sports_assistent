"""Training analytics."""
